VERSION = (2014, 1)
VERSION_STATUS = ""
VERSION_TEXT = ".".join(str(x) for x in VERSION) + VERSION_STATUS

__version__ = VERSION_TEXT
